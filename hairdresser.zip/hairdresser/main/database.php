<?php

$servername = "localhost";
$user = 'root';
$password = 'root';
$db = 'hairdresser';
$host = 'localhost';



$mysqli = new mysqli($servername, $username, $password, $dbname);

if ($mysqli->connect_error){
    die("Connection error: " . $mysqli->connect_error);
}

return $mysqli;