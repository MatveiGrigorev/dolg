<?php
require 'database.php'; // Подключение к базе данных
session_start();

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Получение данных текущего пользователя
$user_id = $_SESSION['user_id'];
$user_query = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$user_query->execute([$user_id]);
$user = $user_query->fetch(PDO::FETCH_ASSOC);

// Проверка роли
$role_id = $user['role_id'];

// Получение записей клиента
if ($role_id == 3) { // Клиент
    $appointments_query = $pdo->prepare("
        SELECT a.appointment_id, s.service_name, s.price, s.duration, u.name AS master_name, 
               a.appointment_date, st.status_name
        FROM appointments a
        JOIN services s ON a.service_id = s.service_id
        JOIN users u ON a.master_id = u.user_id
        JOIN statuses st ON a.status_id = st.status_id
        WHERE a.client_id = ?
        ORDER BY a.appointment_date DESC
    ");
    $appointments_query->execute([$user_id]);
    $appointments = $appointments_query->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <!-- Header -->
    <?php include 'header.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">Личный кабинет</h1>
        <div class="card my-4">
            <div class="card-body">
                <h3>Ваши данные</h3>
                <p><strong>Имя:</strong> <?= htmlspecialchars($user['name']) ?></p>
                <p><strong>Логин:</strong> <?= htmlspecialchars($user['login']) ?></p>
                <p><strong>Роль:</strong> <?= $role_id == 3 ? 'Клиент' : ($role_id == 2 ? 'Мастер' : 'Администратор') ?></p>
            </div>
        </div>

        <!-- История записей -->
        <?php if ($role_id == 3): ?>
        <h3>Ваши записи</h3>
        <?php if (!empty($appointments)): ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Услуга</th>
                        <th>Мастер</th>
                        <th>Дата</th>
                        <th>Цена</th>
                        <th>Статус</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($appointments as $appointment): ?>
                        <tr>
                            <td><?= htmlspecialchars($appointment['service_name']) ?></td>
                            <td><?= htmlspecialchars($appointment['master_name']) ?></td>
                            <td><?= date('d.m.Y H:i', strtotime($appointment['appointment_date'])) ?></td>
                            <td><?= htmlspecialchars($appointment['price']) ?> руб.</td>
                            <td><?= htmlspecialchars($appointment['status_name']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>У вас пока нет записей.</p>
        <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
</body>
</html>
