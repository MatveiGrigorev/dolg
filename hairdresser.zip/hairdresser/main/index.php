<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Парикмахерская</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
    <!-- Header -->
    <header class="bg-dark text-white py-3">
        <div class="container d-flex justify-content-between align-items-center">
            <h1 class="fs-4">Парикмахерская "Стиль"</h1>
            <div>
                <a href="login.html" class="btn btn-outline-light me-2">Войти</a>
                <a href="signup.html" class="btn btn-outline-light">Зарегистрироваться</a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero bg-light text-center">
        <div class="container">
            <h2 class="mb-4">Добро пожаловать в парикмахерскую "Стиль"</h2>
            <p class="mb-5">Мы создаем ваш уникальный стиль с заботой и профессионализмом.</p>
            <a href="#booking" class="btn btn-primary btn-lg">Записаться сейчас</a>
        </div>
    </section>

    <!-- About Us Section -->
    <section id="about" class="py-5 bg-white">
        <div class="container">
            <h2 class="text-center mb-4">О нас</h2>
            <p class="text-center">Наша команда профессионалов работает с каждым клиентом индивидуально, создавая образы, которые подчеркивают вашу уникальность.</p>
            <div class="row mt-4">
                <div class="col-md-6">
                    <img src="./img/about.png" alt="Парикмахерская" class="img-fluid rounded">
                </div>
                <div class="col-md-6">
                    <h3>Почему выбирают нас?</h3>
                    <ul>
                        <li>Профессиональные мастера</li>
                        <li>Индивидуальный подход</li>
                        <li>Современные техники и материалы</li>
                        <li>Доступные цены</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Booking Section -->
    <section id="booking" class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-4">Онлайн-запись</h2>
            <form action="process_booking.php" method="POST" class="row g-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Имя</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Ваше имя" required>
                </div>
                <div class="col-md-6">
                    <label for="phone" class="form-label">Телефон</label>
                    <input type="tel" class="form-control" id="phone" name="phone" placeholder="+7 (999) 999-99-99" required>
                </div>
                <div class="col-md-6">
                    <label for="service" class="form-label">Услуга</label>
                    <select id="service" name="service" class="form-select" required>
                        <option selected disabled>Выберите услугу...</option>
                        <option value="Стрижка">Стрижка</option>
                        <option value="Окрашивание">Окрашивание</option>
                        <option value="Укладка">Укладка</option>
                        <option value="Мужская стрижка">Мужская стрижка</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="date" class="form-label">Дата</label>
                    <input type="date" class="form-control" id="date" name="date" required>
                </div>
                <div class="col-md-12">
                    <label for="notes" class="form-label">Комментарии</label>
                    <textarea id="notes" name="notes" class="form-control" rows="3" placeholder="Дополнительные пожелания"></textarea>
                </div>
                <div class="col-12 text-center">
                    <button type="submit" class="btn btn-primary">Записаться</button>
                </div>
            </form>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-3">
        <p>© 2024 Парикмахерская "Стиль". Все права защищены.</p>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
