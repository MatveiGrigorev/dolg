<?php
session_start();
require 'database.php';

// Проверка, что форма была отправлена
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получаем данные из формы
    $login = $_POST['login'];
    $password = $_POST['password'];

    // Проверка на пустые значения
    if (empty($login) || empty($password)) {
        $_SESSION['error'] = 'Заполните все поля!';
        header('Location: login.html');
        exit();
    }

    // Подготовка запроса для проверки пользователя в базе данных
    $query = $pdo->prepare("SELECT * FROM users WHERE login = ?");
    $query->execute([$login]);
    $user = $query->fetch(PDO::FETCH_ASSOC);

    // Если пользователь найден и пароль совпадает
    if ($user && password_verify($password, $user['password'])) {
        // Создание сессии
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_role'] = $user['role_id'];
        
        // Перенаправление на страницу личного кабинета
        header('Location: user_dashboard.php');
        exit();
    } else {
        $_SESSION['error'] = 'Неверный логин или пароль!';
        header('Location: login.html');
        exit();
    }
} else {
    // Если доступ не с формы, перенаправляем на страницу входа
    header('Location: login.html');
    exit();
}
?>
